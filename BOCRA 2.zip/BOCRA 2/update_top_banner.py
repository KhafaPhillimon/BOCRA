import os
import re

def update_top_banner(content):
    # Find the top-banner section and replace its content
    pattern = re.compile(r'(<div class="top-banner" id="top-banner">.*?<div class="container top-banner-content">)(.*?)(</div>\s*</div>)', re.DOTALL)
    
    new_inner = """
      <div class="top-utility-stack">
        <a href="https://registration.bocra.org.bw/" target="_blank" class="top-bar-link"><i class="fa-solid fa-laptop"></i> BOCRA Portal</a>
        <a href="licensing.html" class="top-bar-link"><i class="fa-solid fa-file-signature"></i> Licensing</a>
      </div>
      <div class="search-box">
        <i class="fa-solid fa-magnifying-glass"></i>
        <span>Search BOCRA</span>
      </div>"""
    
    return pattern.sub(r'\1' + new_inner + r'\3', content)

html_files = [f for f in os.listdir('.') if f.endswith('.html')]

for file_path in html_files:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    updated_content = update_top_banner(content)
    
    if updated_content != content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(updated_content)
        print(f"Updated {file_path}")
    else:
        print(f"No changes for {file_path}")
